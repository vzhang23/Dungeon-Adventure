using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommonAttribute : MonoBehaviour
{

    public float totalHealth;
    public float hp;
    public float attack;
    public float defense;
    public float moveSpeed;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }

}
